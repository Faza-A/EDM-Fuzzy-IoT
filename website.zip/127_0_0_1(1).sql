-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 19, 2020 at 09:43 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `earthquake`
--
CREATE DATABASE IF NOT EXISTS `earthquake` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `earthquake`;

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

CREATE TABLE `akun` (
  `username` varchar(50) NOT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `level` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`username`, `pass`, `level`) VALUES
('admin', 'admin123', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `fuzzy`
--

CREATE TABLE `fuzzy` (
  `id` int(10) NOT NULL,
  `hasil` int(2) NOT NULL,
  `pga1` float DEFAULT NULL,
  `pga2` float DEFAULT NULL,
  `pga3` float DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `waktu` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fuzzy`
--

INSERT INTO `fuzzy` (`id`, `hasil`, `pga1`, `pga2`, `pga3`, `tanggal`, `waktu`) VALUES
(1, 0, 9.2, 9.6, 9.6, '2020-07-18', '01:22:50'),
(2, 0, 154, 167, 167, '2020-07-18', '08:24:30'),
(3, 0, 100, 110, 105, '2020-07-18', '09:16:23'),
(4, 0, 90, 92, 94, '2020-07-18', '14:08:10');

-- --------------------------------------------------------

--
-- Table structure for table `knn`
--

CREATE TABLE `knn` (
  `id` int(10) NOT NULL,
  `hasilk` int(2) NOT NULL,
  `pga1` float DEFAULT NULL,
  `pga2` float DEFAULT NULL,
  `pga3` float DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `waktu` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sensor1`
--

CREATE TABLE `sensor1` (
  `id` int(11) NOT NULL,
  `pga` float DEFAULT NULL,
  `sigbmkg` varchar(3) NOT NULL,
  `longtitude` varchar(55) NOT NULL,
  `latitude` varchar(55) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `waktu` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sensor1`
--

INSERT INTO `sensor1` (`id`, `pga`, `sigbmkg`, `longtitude`, `latitude`, `tanggal`, `waktu`) VALUES
(1, 0.00014, 'I', '-7.802843', '110.374139', '2020-06-01', '15:25:10'),
(2, 0.00034, 'I', '-7.802843', '110.374139', '2020-06-01', '15:27:10'),
(3, 0.00036, 'I', '-7.802843', '110.374139', '2020-06-01', '15:29:10'),
(4, 0.8, 'I', '107.629659', '-6.976923', '2020-07-12', '05:46:26'),
(5, 1, 'I', '107.629659', '-6.976923', '2020-07-12', '05:57:41'),
(6, 2.9, 'II', '107.629659', '-6.976923', '2020-07-15', '23:27:11'),
(7, 9.1, 'II', '107.629659', '-6.976923', '2020-07-16', '01:18:39'),
(8, 9.4, 'II', '107.629659', '-6.976923', '2020-07-18', '01:08:47'),
(9, 9.2, 'II', '107.629659', '-6.976923', '2020-07-18', '01:23:12'),
(10, 154, 'III', '107.629659', '-6.976923', '2020-07-18', '08:24:52'),
(11, 100, 'III', '107.629659', '-6.976923', '2020-07-18', '09:17:58'),
(12, 90, 'III', '107.629659', '-6.976923', '2020-07-18', '14:09:29');

-- --------------------------------------------------------

--
-- Table structure for table `sensor2`
--

CREATE TABLE `sensor2` (
  `id` int(11) NOT NULL,
  `pga` float NOT NULL,
  `sigbmkg` varchar(3) NOT NULL,
  `longtitude` varchar(55) DEFAULT NULL,
  `latitude` varchar(55) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `waktu` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sensor2`
--

INSERT INTO `sensor2` (`id`, `pga`, `sigbmkg`, `longtitude`, `latitude`, `tanggal`, `waktu`) VALUES
(1, 0.50014, 'IV', '-7.802845', '110.374136', '2020-06-01', '15:25:10'),
(2, 0.50014, 'IV', '-7.802845', '110.374136', '2020-06-01', '15:27:10'),
(3, 0.00036, 'I', '-7.802845', '110.374136', '2020-06-01', '15:29:10'),
(4, 0.6, 'I', '107.629340', '-6.976650', '2020-07-12', '05:46:26'),
(5, 2.1, 'I', '107.629340', '-6.976650', '2020-07-12', '05:57:41'),
(6, 3.1, 'II', '107.629340', '-6.976650', '2020-07-15', '23:27:11'),
(7, 9.4, 'II', '107.629340', '-6.976650', '2020-07-16', '01:18:39'),
(8, 9.1, 'II', '107.629340', '-6.976650', '2020-07-18', '01:08:47'),
(9, 9.6, 'II', '107.629340', '-6.976650', '2020-07-18', '01:23:12'),
(10, 167, 'III', '107.629340', '-6.976650', '2020-07-18', '08:24:52'),
(11, 110, 'III', '107.629340', '-6.976650', '2020-07-18', '09:17:58'),
(12, 92, 'III', '107.629340', '-6.976650', '2020-07-18', '14:09:29');

-- --------------------------------------------------------

--
-- Table structure for table `sensor3`
--

CREATE TABLE `sensor3` (
  `id` int(11) NOT NULL,
  `pga` float DEFAULT NULL,
  `sigbmkg` varchar(3) NOT NULL,
  `longtitude` varchar(55) DEFAULT NULL,
  `latitude` varchar(55) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `waktu` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sensor3`
--

INSERT INTO `sensor3` (`id`, `pga`, `sigbmkg`, `longtitude`, `latitude`, `tanggal`, `waktu`) VALUES
(1, 0.00035, 'I', '-7.802847', '110.374140', '2020-06-01', '15:25:10'),
(2, 0.50016, 'IV', '-7.802847', '110.374140', '2020-06-01', '15:27:10'),
(3, 0.5, 'IV', '-7.802847', '110.374140', '2020-06-01', '15:29:10'),
(4, 1, 'I', '107.629643', '-6.976416', '2020-07-12', '05:46:26'),
(5, 2.2, 'I', '107.629643', '-6.976416', '2020-07-12', '05:57:41'),
(6, 3.3, 'II', '107.629643', '-6.976416', '2020-07-15', '23:27:11'),
(7, 9, 'II', '107.629643', '-6.976416', '2020-07-16', '01:18:39'),
(8, 9, 'II', '107.629643', '-6.976416', '2020-07-18', '01:08:47'),
(9, 9, 'II', '107.629643', '-6.976416', '2020-07-18', '01:08:47'),
(10, 9.6, 'II', '107.629643', '-6.976416', '2020-07-18', '01:23:12'),
(11, 105, 'III', '107.629643', '-6.976416', '2020-07-18', '09:17:58'),
(12, 94, 'III', '107.629643', '-6.976416', '2020-07-18', '14:09:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `fuzzy`
--
ALTER TABLE `fuzzy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `knn`
--
ALTER TABLE `knn`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sensor1`
--
ALTER TABLE `sensor1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sensor2`
--
ALTER TABLE `sensor2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sensor3`
--
ALTER TABLE `sensor3`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fuzzy`
--
ALTER TABLE `fuzzy`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `knn`
--
ALTER TABLE `knn`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sensor1`
--
ALTER TABLE `sensor1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `sensor2`
--
ALTER TABLE `sensor2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `sensor3`
--
ALTER TABLE `sensor3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
